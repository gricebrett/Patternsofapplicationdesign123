import UIKit

var str = "Hello, playground"

//bio
//name
var string = "Name: Brett Grice"
//Age
var string2 = "Age: 30"
//Birthplace
var string3 = "Birth Place: Pensacola, Florida"
//Aspiration
var string4 = " I want to further my career in the banking world but with the UX and digital side of things"
