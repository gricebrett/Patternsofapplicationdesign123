import UIKit

var str = "Hello, playground"
//BIO
var string2 = "Name: Brett Grice"
var string3 = "Age: 30"
var string4 = "Birth Place: Pensacola,Fl"

var string5 = "Career Aspritation: To work in either web design, UX design or further my career in the banking world."

